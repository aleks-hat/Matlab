%10/9/19 redid last exam problem as a function, plotted trjectory of the
%cannon ball: did distance traveled, time in air, the degree of the
%trajectory, the initial velocity, the height of the building, and the
%total distance traveled , had a legend, axis titles.

%DO 
%THIS 
%FOR 
%WEEKLY 
%ASSIGNMENT