close all 
clear all
clc

% load('CCMP_HurricaneIsabel_20030912.mat')
% wspd = sqrt(uwnd.^2+vwnd.^2);
% pcolor(lon, lat, squeeze(wspd(:,:,1))');
% colorbar
% shading flat
% xlim([290 315])
% ylim([10 30])
% axis square
% colormap('jet')
% 
% indlat1=find(lat<=10, 1, 'Last')
% indlat2=find(lat>=30, 1, 'First')
% indlon1=find(lon<=290, 1, 'Last')
% indlon2=find(lon>=315, 1, 'First')
% 
% uwnd_s=uwnd([indlon1:indlon2], [indlat1: indlat2], :);
% vwnd_s=vwnd([indlon1:indlon2], [indlat1: indlat2], :);
% 
% lat_s= lat(indlat1:indlat2);
% lon_s= lon(indlon1:indlon2);
% 
% save('CCMP_HurricaneIsabel_20030912.mat', 'lat_s', 'lon_s',...
%     'uwnd_s', 'vwnd_s', 'timeCCMP')

clear all
close all
clc

load('CCMP_HurricaneIsabel_20030912.mat')

wspd = sqrt(uwnd_s.^2+vwnd_s.^2);
pcolor(lon_s, lat_s, squeeze(wspd(:,:,1))');
colorbar
shading flat
% xlim([290 315])
% ylim([10 30])
axis square
colormap('jet')
set(gcf, 'Color', 'w')
hold on
quiver(lon_s, lat_s, squeeze(uwnd_s(:, :, 1))',squeeze(vwnd_s(:, :, 1))',...
    2, 'w');

%circle
xs=1*cos([0:0.001:2*pi]);
ys=1*sin([0:0.001:2*pi]);
plot(xs+305, ys+21, 'k', 'LineWidth', 5)
%fill instead of plot will fill circle

%square

plot([-1 1 1 -1 -1]+305, [-1 -1 1 1 -1]+21, 'k', 'LineWidth', 3)

