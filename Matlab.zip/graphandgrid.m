close all 
clear all
clc

x = 0:0.01:10;
t=0:0.01:5;

[X, T] = meshgrid(x, t);
A = 0.5;
f=1; %hertz
lambda=3; %m
Y = A.*sin(2*pi.*f.*T-2.*pi.*X/lambda);
%contourf(X, T, Y); colorbar
% xlabel('Position')
% ylabel('Time')

figure('position' ,[10 10 800 600])

% for i=1:501
%         subplot(1, 2, 1)
%     plot(X(i,:), Y(i,:))
%     title(['for t = ' num2str(t(i)) ' in s'])
%     subplot(2, 1, 2)
%     contourf(X, Y, T);colorbar;
%     xlabel('Position')
%     ylabel('Time')
%     hold on 
%     plot([0 10] , [t(i) t(i)], 'w')
%     hold off
%     pause(0.1)
% end

[X,Y] = meshgrid([-2:.2:2][-2:.2:2], [1:-0.05:0]);
Z = X.*exp(-X.^2 - Y.^2.*T);
for i=1:11
[DX,DY] = gradient(squeeze(Z(:, :, i),.2,.2);

figure
surf(squeeze(X(:, :, i),Y(:, :, i),Z(:, :, i));colorbar;
colormap('hot')
pause(0.1)
% hold on
% quiver(X,Y,DX,DY)
% hold off
zlim([-2 2])
title(num2str(i)
end 