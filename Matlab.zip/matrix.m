close all
clear all
clc

% apple = 1:15;
% 
% apple = reshape(apple, [5, 3]);

% for i = 1:5
%     for j=1:3
%         display(num2str(apple(i, j)))
%     end
% end

% i1 = -3;
% while i1 < 10
%     display(num2str(i1))
%     if i1 == 3;
%         break
%     end
%     i1 = i1+2;
% end

%if statement 

% generate a random interger
a = randi(100, 1);
% 
%if it is even, divide by 2
% if rem(a, 2) == 0
%     display(num2str(a))
%     display('a is even')
%     b = a/2;
% end
% disp(num2str(a))
% if a<30
%     disp('small')
% elseif a>40 && a<50
%     disp('yee haw')
% elseif a<80
%     disp('medium')
% else
%     disp('large')
% end

%case statement
date = datenum(2003, 9, 27,9, 34, 23);
[dayNum, dayString] = weekday(date, 'long', 'en_US');

switch dayString
    case 'Monday'
        disp('Garfield hates Mondays')
    case 'Tuesday'
        disp('Taco Tuesday')
    case 'Wednesday'
        disp('Wed-nes-day')
    case 'Thursday'
        disp('Almost Friday')
    case 'Friday'
        disp('Exam in 3 days')
    otherwise
        disp('Time to relax')
end











