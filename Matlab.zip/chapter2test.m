clear all
close all
clc

% this is a comment and will not be calculated 

s = 0;
N = 10000;

for n = 1:N
    s = s +1/n^2;
    % s = 0 + 1
    % s = 1 + 1/4
    % s = 1.25 + 1/9
    
end

sprintf(' Sum = %g \n', s)

% -------------------------------------------------------------------------------------

close all
clear all
clc

% this prongram will take in a value and calculate the sin and cosine 
% in degrees of that value

N = input(' Enter an angle in Degrees - ');
sprintf('The value of sine is %g and the value for cosine is %g.', sind(N), cosd(N))

sprintf(' N = %g \n', 500)
sprintf(' x = %1.12g \n', pi)
sprintf(' x = %1.10e \n', pi)
sprintf(' x = %6.2f \n', pi)
sprintf(' x = %12.8f y = %12.8f \n', 5, exp(5))

% ---------------------------------------------------------------------------------------

close all 
clear all
clc

%Kinematics formula x=1/2.*a.*t.^2 + vi.*t + xi

ax=0;  % initial acceleration in the x-direction
vix=15; % initial velocity in the x-direction
xi=10; % initial position in the x-direction
ay=-1.62; % initial acceleration in the y-direction
viy=10; % initial velocity in the y-direction
yi=100; % initial position in the y-direction
t=0:0.001:18.0; % time considered
x = 1/2.*ax.*t.^2 + vix.*t + xi;
y = 1/2.*ay.*t.^2 + viy.*t + yi;

plot(x, y)



