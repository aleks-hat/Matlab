clear all 
close all
clc

%% block of code

g = 9.81; %m/s^2
t = linspace(0,1000,10001)
f = 1 - exp(-g.*t);





 